export default class User {
  id: number;
 
  name: string;
  password: string;
  // measuredAt: string;
}
