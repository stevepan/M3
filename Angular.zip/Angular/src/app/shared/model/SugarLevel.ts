export default class SugarLevel {
  id: number;
  value: number;
  name: string;
  measuredAt: string;
}
