import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import User from '../model/User';

@Injectable()
export default class UserService {
  public API = 'http://localhost:8080/api';
  public USERS_API = `${this.API}/users`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<User[]> {
    return this.http.get<User[]>(`${this.USERS_API}`);
  }

  get(id: string) {
    return this.http.get(`${this.USERS_API}/${id}`);
  }

  save(user: User): Observable<any> {
    let result: Observable<Object>;
    // if (user.id) {
    //   result = this.http.put(`${this.USERS_API}/${user.id}`, user);
    // } else 
    {
      result = this.http.post(this.USERS_API, user);
    }
    return result;
  }

  login(user: User): Observable<any> {
    //return this.http.get(`${this.USERS_API}/${user.name}/${user.password}`);
    let data = {name: user.name, password: user.password};
    return this.http.get(`${this.USERS_API}`, {params: data});
  }


  remove(id: number) {
    return this.http.delete(`${this.USERS_API}/${id.toString()}`);
  }
}
