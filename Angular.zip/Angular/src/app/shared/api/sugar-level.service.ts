import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import SugarLevel from '../model/SugarLevel';
// import User from '../model/User';

@Injectable()
export default class SugarLevelService {
  public API = 'http://localhost:8080/api';
  public SUGARLEVELS_API = `${this.API}/sugarlevels`;
  public USERS_API = `${this.API}/users`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<SugarLevel[]> {
    return this.http.get<SugarLevel[]>(`${this.SUGARLEVELS_API}`);
  }

  get(id: string) {
    return this.http.get(`${this.SUGARLEVELS_API}/${id}`);
  }

  save(sugarLevel: SugarLevel): Observable<any> {
    let result: Observable<Object>;
    if (sugarLevel.id) {
      result = this.http.put(`${this.SUGARLEVELS_API}/${sugarLevel.id}`, sugarLevel);
    } else {
      result = this.http.post(this.SUGARLEVELS_API, sugarLevel);
    }
    return result;
  }

  // saveUser(user: User): Observable<any> {
  //   let result: Observable<Object>;
  //   if (user.id) {
  //     result = this.http.put(`${this.USERS_API}/${user.id}`, user);
  //   } else {
  //     result = this.http.post(this.USERS_API, user);
  //   }
  //   return result;
  // }

  remove(id: number) {
    return this.http.delete(`${this.SUGARLEVELS_API}/${id.toString()}`);
  }
}
