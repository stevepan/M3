import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute, Router } from '@angular/router';

import UserService from '../shared/api/user.service';
import User from '../shared/model/User';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export default class UserEditComponent implements OnInit, OnDestroy {
  user: User = new User();

  sub: Subscription;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private userSeervice: UserService) {
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      const id = params['id'];
      if (id) {
        this.userSeervice.get(id).subscribe((user: any) => {
          if (user) {
            this.user = user;
            // this.sugarLevel.measuredAt = new Date(this.sugarLevel.measuredAt).toISOString();
          } else {
            console.log(`User with id '${id}' not found, returning to list`);
            this.goToList();
          }
        });
      }
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  goToList() {
    this.router.navigate(['/sugarlevel-list']);
  }

  goToUserLogin() {
    this.router.navigate(['/user-login']);
  }

  save(form: any) {
    this.userSeervice.save(form).subscribe(result => {
      //this.goToList();
      this.goToUserLogin();
    }, error => console.error(error));
  }

  remove(id: number) {
    this.userSeervice.remove(id).subscribe(result => {
      this.goToList();
    }, error => console.error(error));
  }
}
